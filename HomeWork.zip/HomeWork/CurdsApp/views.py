from django.shortcuts import render

# Create your views here.
result = []
def cal(request):
    if request.method =='POST':     
        if request.POST.get('1'):  
            result.append('1')       
            output = ''.join(result) 
            print(output)

        elif request.POST.get('2'):
            result.append('2')
            output = ''.join(result)
            print(output)
        elif request.POST.get('3'):
            result.append('3')
            output = ''.join(result)
            print(output)
        elif request.POST.get('4'):
            result.append('4')
            output = ''.join(result)
            print(output)
        elif request.POST.get('5'):
            result.append('5')
            output = ''.join(result)
            print(output)
            
        elif request.POST.get('6'):
            result.append('6')
            output = ''.join(result)
            print(output)
        elif request.POST.get('7'):
            result.append('7')
            output = ''.join(result)
            print(output)
        elif request.POST.get('8'):
            result.append('8')
            output = ''.join(result)
            print(output)
        elif request.POST.get('9'):
            result.append('9')
            output = ''.join(result)
            print(output)
        elif request.POST.get('+'):
            result.append('+')
            output = ''.join(result)
            print(output)
        elif request.POST.get('-'):
            result.append('-')
            output = ''.join(result)
            print(output)
        elif request.POST.get('*'):
            qa=result.append('*')
            output = ''.join(result)
            print(output)
        elif request.POST.get('/'):
            result.append('/')
            output = ''.join(result)
            print(output)
        elif request.POST.get('0'):
            result.append('0')
            output = ''.join(result)
            if output=="3240" :
                output='Secret code'

            print(output)
        elif request.POST.get('C'):
            result.clear()

        elif request.POST.get('='): 
            try:                    
                r = ''.join(result)    
                output=eval(r)          
                print(output)
                result.clear()       
            except:
                output='00'
                result.clear()    
    return render(request,'cal.html',locals(),)